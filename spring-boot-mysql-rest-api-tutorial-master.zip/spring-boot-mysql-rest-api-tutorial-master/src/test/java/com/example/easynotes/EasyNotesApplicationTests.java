package com.example.easynotes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class EasyNotesApplicationTests {

	@Test
	public void contextLoads() {
	}

}
